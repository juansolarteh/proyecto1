package com.practices.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.Firestore;
import com.practices.commons.GenericServiceImpl;
import com.practices.dto.PracticesDTO;
import com.practices.model.Practices;

@Service
public class PracticesServiceImpl  extends GenericServiceImpl<Practices, PracticesDTO> implements PracticesServiceAPI{
	
	@Autowired
	private Firestore firestore;

	@Override
	public CollectionReference getCollection() {
		return firestore.collection("Practices");
	}
	
	@Override
	public List<PracticesDTO> getByStudent(String idStudent) throws Exception {
		return getFromMapByKey("students", idStudent);
	}
	
	@Override
	public List<Date> getDatesByTopic(String idTopic) throws Exception {
		List<Date> dates = new ArrayList<Date>();
		List<PracticesDTO> practices = getListByFieldPath("topic_id", idTopic);
		for (PracticesDTO practice : practices) {
			dates.add(practice.getStart());
		}
		return dates;
	}
}
